﻿/*
 * Written By:
 * 
 * Cameron McNeill
 * 170014393
 *
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PaintWAR
{
    public partial class Form1 : Form
    {
        // Create array of buttons
        Button[,] newBtn;
        player p1;
        player p2;

        // Global variables
        int player_turn = 1;
        int gameBorder;
        int black_squares;


        //============================================================================================================================
        private void testingVals()
        {
            p1 = new player(Color.Purple, "Cammy");
            p2 = new player(Color.Green, "Steven");
            newBtn = new Button[25, 25];
            gameBorder = newBtn.GetLength(0) - 1;
            input_group.Visible = false;
            startGame();
        }


        //============================================================================================================================
        // Form Setup
        //============================================================================================================================
        public Form1()
        {
            InitializeComponent();
        }


        //============================================================================================================================
        private void Form1_Load(object sender, EventArgs e)
        {
            // Set location for each of the control groups
            input_group.Location = new Point(174, 125);
            winner_group.Location = new Point(174, 125);

            // Disable the new game button as no game has been set up yet
            mi_new_game.Enabled = false;
        }


        //============================================================================================================================
        // Game Setup
        //============================================================================================================================
        private void initGame()
        {

            // Check that the user has entered a name into both of the player name fields
            if (txt_player1.Text == "" || txt_player2.Text == "")
            {
                // Display error message
                MessageBox.Show("You must enter 2 names to start the game.", "Player Name Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check that the names entered are no longer than 6 characters
            if (txt_player1.Text.Length > 6 || txt_player2.Text.Length > 6)
            {
                // Display error message
                MessageBox.Show("You must enter 2 names that are a maximum of 6 characters to start the game.", "Player Name Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check that the user has selected a colour for each player
            if (btn_p1_colour.BackColor.Name.ToString() == "ff404040" || btn_p2_colour.BackColor.Name.ToString() == "ff404040")
            {
                // Display error message
                MessageBox.Show("You must select a colour for each player to start the game.", "Player Colour Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check that the user has enetered two different colours for the players as
            // game will become imposible to play if they are the same colour
            if (btn_p1_colour.BackColor == btn_p2_colour.BackColor)
            {
                MessageBox.Show("You must select different colours for each player to start the game.", "Player Colour Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Initilise the two player objects with the colours and names entered
            p1 = new player(btn_p1_colour.BackColor, txt_player1.Text.ToString());
            p2 = new player(btn_p2_colour.BackColor, txt_player2.Text.ToString());

            // Check that the user has selected one of the grid sizes for the game
            if (cb_grid_size.Text.ToString() != "")
            {
                // Recieve the size of the grid from the drop down box
                int grid_size_x = Convert.ToInt32(cb_grid_size.Text.ToString().Substring(0, 2));
                int grid_size_y = Convert.ToInt32(cb_grid_size.Text.ToString().Substring(5, 2));
                
                // Initilise the array of buttons to the size chosen by the user
                newBtn = new Button[grid_size_x, grid_size_y];

                // Set the game border to the width of the grid - 1. This will be used to ensure
                // the placing of paint squares works as intended
                gameBorder = grid_size_x - 1;
            }
            else
            {
                // Display error message
                MessageBox.Show("You must select a grid size to start the game.", "Grid Size Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Make sure the input box and winner box are hidden for now
            input_group.Visible = false;
            winner_group.Visible = false;

            // Activate the new game button as a game has been set up
            mi_new_game.Enabled = true;

            // Start the game
            startGame();
        }


        //============================================================================================================================
        private void startGame()
        {
            // Set up variables
            int w = 600 / newBtn.GetLength(0);
            int h = 600 / newBtn.GetLength(1);
            int yOffSet = 28;
            int xOffSet = 2;

            control_group.Location = new Point(610, 27);
            control_group.Visible = true;

            // Create grid of buttons
            for (int x = 0; x < newBtn.GetLength(0); x++)
            {
                for (int y = 0; y < newBtn.GetLength(1); y++)
                {
                    // Create each button and initilise for the start of the game
                    btnCoords coords = new btnCoords(x, y);
                    newBtn[x, y] = new Button();
                    newBtn[x, y].SetBounds((x * w) + xOffSet, (y * h) + yOffSet, w, h);
                    newBtn[x, y].BackColor = Color.Honeydew;
                    newBtn[x, y].FlatStyle = FlatStyle.Flat;
                    newBtn[x, y].Tag = coords;
                    newBtn[x, y].Click += new EventHandler(buttonClicked);
                    Controls.Add(newBtn[x, y]);
                }
            }

            // Ensure the players points are reset to 0
            p1.setPoints(0);
            p2.setPoints(0);

            black_squares = 0;

            // Update the GUI with the names of the players
            lbl_p1_name.Text = p1.getName();
            lbl_p2_name.Text = p2.getName();

            updateStats();
        }


        //============================================================================================================================
        // Functions
        //============================================================================================================================
        private void newGame()
        {
            player_turn = 1;

            // Loop over all the buttons in the grid and reset them all back to the original settings
            for (int x = 0; x < newBtn.GetLength(0); x++)
            {
                for (int y = 0; y < newBtn.GetLength(1); y++)
                {
                    newBtn[x, y].BackColor = Color.Honeydew;
                    newBtn[x, y].Enabled = true;
                }
            }

            // Ensure the players points are reset to 0
            p1.setPoints(0);
            p2.setPoints(0);

            // Reset the black square counter
            black_squares = 0;

            winner_group.Visible = false;

            updateStats();
        }


        //============================================================================================================================
        private Color getPlayerColour()
        {
            // Check whos turn it is (Player 1 = 1 --> Player 2 = -1)
            // Return the colour of the appropriate player
            if (player_turn > 0) { return p1.getColor(); }
            else { return p2.getColor(); }
        }


        //============================================================================================================================
        private void updateStats()
        {
            // Check whos turn it is (Player 1 = 1 --> Player 2 = -1)
            if (player_turn > 0)
            {
                // Display the name of player 1
                lbl_player.Text = p1.getName();
                // Change the item count on each of the weapon buttons
                btn_paint_bomb.Text = ("Paint Bomb (" + p1.getBombs() + ")");
                btn_paint_dripping.Text = ("Dripping Paint (" + p1.getDripping() + ")");
                btn_paint_infected.Text = ("Infected Paint (" + p1.getInfected() + ")");
            }
            else
            {
                // Display the name of player 2
                lbl_player.Text = p2.getName();
                // Change the item count on each of the weapon buttons
                btn_paint_bomb.Text = ("Paint Bomb (" + p2.getBombs() + ")");
                btn_paint_dripping.Text = ("Dripping Paint (" + p2.getDripping() + ")");
                btn_paint_infected.Text = ("Infected Paint (" + p2.getInfected() + ")");
            }

            // Get the current points from each of the players and update the display 
            lbl_points_1.Text = Convert.ToString(p1.getPoints());
            lbl_points_2.Text = Convert.ToString(p2.getPoints());

            // Reset the weapon choice back to the default of Paint Blob
            lbl_weapon_choice.Text = "Paint Blob";
        }


        //============================================================================================================================
        private void addPoints(int points)
        {
            // Check whos turn it is (Player 1 = 1 --> Player 2 = -1)
            // Add points the the current player
            if (player_turn > 0) { p1.addPoints(points); }
            else { p2.addPoints(points); }
        }


        //============================================================================================================================
        private void subPoints(int points, int plr)
        {
            // Check whos turn it is (Player 1 = 1 --> Player 2 = -1)
            // Remove points from the player, both specified by parameters
            if (plr > 0) { p2.subPoints(points);
            } else { p1.subPoints(points); }
        }


        //============================================================================================================================
        public bool weaponCanUse(string weapon)
        {
            // Check whos turn it is (Player 1 = 1 --> Player 2 = -1)
            // Check if the counter for the weapons is greater than 0, meaning that the player
            // is able to use it
            if (player_turn > 0)
            {
                if (p1.checkWeapon(weapon) > 0)
                {
                    return true;
                }
            }
            else
            {
                if (p2.checkWeapon(weapon) > 0)
                {
                    return true;
                }
            }

            return false;
        }


        //============================================================================================================================
        public void weaponUsed(string weapon)
        {
            // Check whos turn it is (Player 1 = 1 --> Player 2 = -1)
            // This is called when a weapon is used. It will decrease the count
            // for that weapon for the player that just used it
            if (player_turn > 0)
            {
                p1.useWeapon(weapon);
            }
            else
            {
                p2.useWeapon(weapon);
            }
        }


        //============================================================================================================================
        private void checkWinState()
        {
            // Check how many squares there are on the board that are no black
            int total = (newBtn.GetLength(0) * newBtn.GetLength(1)) - black_squares;

            // Check how many total coloured squares there are on the board
            int p_total = (p1.getPoints() + p2.getPoints());
            
            //Console.WriteLine("Black Squares --> " + black_squares + "        Total (Not Black) --> " + total + "       Total (Coloured) --> " + p_total);

            // Check to see if the total number of squares that are coloured is equal to the number of squares
            // that are not black. If true, this means that the board is full and the game should end
            if (total == p_total)
            {
                // Create a string with the winning message
                String win_message = " Wins!";

                string winner = "";
                
                // If player one has won the game, recieve this players name and add it to
                // the beginning of the win message. If the second player has won, recieve
                // their name instead
                if (p1.getPoints() > p2.getPoints())
                {
                    lbl_winner.Text = p1.getName() + win_message;
                    Console.WriteLine("Winner is --> " + p1.getName());
                    winner = p1.getName();
                }
                else
                {
                    lbl_winner.Text = p2.getName() + win_message;
                    Console.WriteLine("Winner is --> " + p2.getName());
                    winner = p2.getName();
                }


                // Save the game stats to the histroy file
                string sep = ",";
                StringBuilder csvcontent = new StringBuilder();
                csvcontent.Append(p1.getName() + sep + p1.getPoints() + sep + p2.getPoints() + sep + p2.getName() +
                                  sep + winner + sep + newBtn.GetLength(0) + "x" + newBtn.GetLength(0) + "\n");
                File.AppendAllText("History.csv", csvcontent.ToString());

                // Set the winner group to visible and ensure it is at the front of all the objects
                winner_group.Visible = true;
                winner_group.BringToFront();
            }
        }


        //============================================================================================================================
        // Event Handlers
        //============================================================================================================================
        private void buttonClicked(object sender, EventArgs e)
        {
            // Recieve the button that was clicked and get the coordinates attached to it
            Button clicked = sender as Button;
            btnCoords coords = (btnCoords)clicked.Tag;

            bool success = true;

            // Get the current weapon selected
            string weapon_choice = lbl_weapon_choice.Text;

            // Get the X and Y coordinates
            int x = coords.getX();
            int y = coords.getY();

            // Check if the infected paint has been chosen
            // This is in its own check before the main switch as it has different functionality
            if (weapon_choice == "Infected Paint")
            {
                if (weaponCanUse("infected") == true)
                {
                    // Disable the button selected
                    clicked.Enabled = false;
                    clicked.BackColor = Color.Black;
                    black_squares++;

                    // Call the weapon function
                    infectedPaint(x, y);
                    weaponUsed("infected");

                    // Update display and check for a win
                    player_turn *= -1;
                    updateStats();
                    checkWinState();
                    return;
                }
                else
                {
                    // Send error message to the player if they do not have enough of the weapon
                    MessageBox.Show("Not enough infected paint to use this", "Out of infected paint", MessageBoxButtons.OK);
                    clicked.Enabled = true;
                    clicked.BackColor = Color.Honeydew;
                }
            }

            // Check the button is not already painted
            if (clicked.BackColor == Color.Honeydew)
            {
                // Disable the button clicked
                clicked.Enabled = false;
                clicked.BackColor = Color.Black;

                switch (weapon_choice)
                {
                    case "Paint Blob":
                        // Call the weapon function
                        paintBlob(x, y);
                        break;

                    case "Paint Bomb":
                        // Check that the weapon is useable
                        if (weaponCanUse("bomb") == true)
                        {
                            // Call the weapon function
                            paintBomb(x, y);
                            weaponUsed("bomb");
                        }
                        else
                        {
                            // Send error message if unable to use
                            MessageBox.Show("Not enough bombs to use this", "Out of bombs", MessageBoxButtons.OK);
                            success = false;
                        }
                        break;

                    case "Dripping Paint":
                        // Check that the weapon is useable
                        if (weaponCanUse("dripping") == true)
                        {
                            // Call the weapon function
                            drippingPaint(x, y);
                            weaponUsed("dripping");
                        }
                        else
                        {
                            // Send error message if unable to use
                            MessageBox.Show("Not enough dripping paint to use this", "Out of dripping paint", MessageBoxButtons.OK);
                            success = false;
                        }
                        break;

                    default:
                        // Send error message if an unexpected value is found
                        Console.WriteLine("Error --> Weapon Switch Statement");
                        break;
                }

                // Check that the turn taken was successful
                if (success == true)
                {
                    // If true then upadte stats and display. Then check if the game has been won or not
                    player_turn *= -1;
                    black_squares++;
                    updateStats();
                    checkWinState();
                } else
                {
                    // If false, return the button to defualt and allow for another turn
                    clicked.Enabled = true;
                    clicked.BackColor = Color.Honeydew;
                }
                
            }
            else
            {
                // Error message if the user tries to paint an already painted square
                Console.WriteLine("Error --> Painted Square Clicked");
            }

        }


        //============================================================================================================================
        private void updateWeaponChoice(object sender, EventArgs e)
        {
            // Get the button clicked
            Button clicked = sender as Button;

            // Set the weapon display to the weapon selected
            lbl_weapon_choice.Text = clicked.Text.Substring(0, (clicked.Text.Length - 4));
        }


        //============================================================================================================================
        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Close the game
            Close();
        }


        //============================================================================================================================
        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Start a new game
            newGame();
        }


        //============================================================================================================================
        private void pickTeamColor(object sender, EventArgs e)
        {
            // Get tbe button clicked 
            Button clicked = sender as Button;

            // Set the team colour to the colour that the player selected
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                clicked.BackColor = colorDialog1.Color;
            }
        }


        //============================================================================================================================
        private void btn_start_game_Click(object sender, EventArgs e)
        {
            // Initilise a new game
            initGame();
        }


        //============================================================================================================================
        private void testingCode(object sender, KeyEventArgs e)
        {
            // Check for crtl+T pressed
            if (e.KeyData == (Keys.Control | Keys.T))
            {
                // Run the game with testing values
                // This allows for quicker testing as tester doesnt need to enter names, colours or grid size
                testingVals();
            }
        }


        //============================================================================================================================
        // Weapons
        //============================================================================================================================
        private void paintBlob(int x, int y)
        {
            // Create an array of offset coordinates for the paint blob
            int[,] paintPoints = { { 0, 3 }, { 0, 2 }, { 0, 1 }, { 0, -3 }, { 0, -2 }, { 0, -1 },
                                   { 1, 2 }, { 1, 1 }, { 1, 0 }, { 1, -1 }, { 1, -2 },
                                   { 2, 1 }, { 2, 0 }, { 2, -1 },
                                   { 3, 0 },
                                   { -1, 2 }, { -1, 1 }, { -1, 0 }, { -1, -1 }, { -1, -2 },
                                   { -2, 1 }, { -2, 0 }, { -2, -1 },
                                   { -3, 0 }
                                 };

            // Call the function to draw the points on the board
            paintArray(x, y, paintPoints, getPlayerColour());
        }


        //============================================================================================================================
        private void paintBomb(int x, int y)
        {
            // Create an array of offset coordinates for the dripping 
            int[,] paintPoints = { { 0, 3 }, { 0, 2 }, { 0, 1 }, { 0, -3 }, { 0, -2 }, { 0, -1 },
                                   { 1, 1 }, { 1, 0 }, { 1, -1 },
                                   { 2, 2 }, { 2, 0 }, { 2, -2 },
                                   { 3, -3 }, { 3, 0 }, { 3, 3},
                                   { -1, -1 }, { -1, 0 }, { -1, 1 },
                                   { -2, -2 }, { -2, 0 }, { -2, 2 },
                                   { -3, -3 }, { -3, 0 }, { -3, 3 }
                                 };

            // Get the colours of the two players
            string p1_colour = p1.getColor().Name.ToString();
            string p2_colour = p2.getColor().Name.ToString();

            for (int i = 0; i < paintPoints.GetLength(0); i++)
            {
                // Set the new x and y coords to the button clicked plus the offset given by the array
                int newx = x + paintPoints[i, 0];
                int newy = y + paintPoints[i, 1];

                // Check that the new point is within the borders to avoid an out of bounds exception
                if (!((newx < 0) || (newy < 0) || (newx > gameBorder) || (newy > gameBorder)))
                {
                    // Get the colour of the button that is at the coords of the new x and y
                    Color btnColor = (Color)newBtn[newx, newy].BackColor;
                    string c = btnColor.Name;

                    if (c == p1_colour)
                    {
                        // If the colour matches the colour of player 1, take a point off of them and
                        // paint the square back to default
                        subPoints(1, -1);
                        newBtn[newx, newy].BackColor = Color.Honeydew;
                    }
                    else if (c == p2_colour)
                    {
                        // If the colour matches the colour of player 2, take a point off of them and
                        // paint the square back to default
                        subPoints(1, 1);
                        newBtn[newx, newy].BackColor = Color.Honeydew;
                    }
                }
            }
        }


        //============================================================================================================================
        private void drippingPaint(int x, int y)
        {
            // Create an array of offset coordinates for the dripping paint
            int[,] paintPoints = { { -3, -1 }, { -2, -1 }, { -1, -1 }, { 0, -1 }, { 1, -1 }, { 2, -1 }, { 3, -1 },
                                   { -4, 0 }, { -3, 0 }, { -2, 0 }, { -1, 0 }, { 1, 0 }, { 2, 0 }, { 3, 0 }, { 4, 0 },
                                   { -3, 1 }, { -2, 1 }, { -1, 1 }, { 0, 1 }, { 1, 1 }, { 2, 1 }, { 3, 1 },
                                   { -2, 2 }, { -1, 2 }, { 0, 2 }, { 2, 2 }, { 3, 2 },
                                   { -2, 3 }, { 0, 3 }, { 3, 3 },
                                   { -2, 4 }, { 0, 4 }, { 3, 4 },
                                   { 0, 5 },
                                   { 0, 6 }
                                 };

            // Call the function to draw the points on the board
            paintArray(x, y, paintPoints, getPlayerColour());
        }


        //============================================================================================================================
        private void infectedPaint(int x, int y)
        {
            // Set the paint colour to black
            Color paintColour = Color.Black;

            // Create an array of offset coordinates for the dripping 
            int[,] paintPoints = { { 0, 3 }, { 0, 2 }, { 0, 1 }, { 0, -3 }, { 0, -2 }, { 0, -1 },
                                   { 1, 2 }, { 1, 1 }, { 1, 0 }, { 1, -1 }, { 1, -2 },
                                   { 2, 1 }, { 2, 0 }, { 2, -1 },
                                   { 3, 0 },
                                   { -1, 2 }, { -1, 1 }, { -1, 0 }, { -1, -1 }, { -1, -2 },
                                   { -2, 1 }, { -2, 0 }, { -2, -1 },
                                   { -3, 0 }
                                 };

            // Get the colours of the players
            string p1_colour = p1.getColor().Name.ToString();
            string p2_colour = p2.getColor().Name.ToString();

            for (int i = 0; i < paintPoints.GetLength(0); i++)
            {
                // Set the new x and y coords to the button clicked plus the offset
                int newx = x + paintPoints[i, 0];
                int newy = y + paintPoints[i, 1];

                if (!((newx < 0) || (newy < 0) || (newx > gameBorder) || (newy > gameBorder)))
                {
                    // Get the colour of the button at the new x and y coords                    
                    Color btnColor = (Color)newBtn[newx, newy].BackColor;
                    string c = btnColor.Name;

                    // Set the button to black, disable it and add 1 to the black square count
                    newBtn[newx, newy].BackColor = paintColour;
                    newBtn[newx, newy].Enabled = false;
                    black_squares++;

                    if (c == p1_colour)
                    {
                        // Sub a point from the player if the black has taken their button
                        // Player parameter is inverted due to a stupid function
                        subPoints(1, -1);
                    }
                    else if (c == p2_colour)
                    {
                        // Sub a point from the player if the black has taken their button
                        // Player parameter is inverted due to a stupid function
                        subPoints(1, 1);
                    }

                }
            }
        }


        //============================================================================================================================
        private void paintArray(int x, int y, int[,] a, Color paintColour)
        {
            // Get the colours of the two players
            string p1_colour = p1.getColor().Name.ToString();
            string p2_colour = p2.getColor().Name.ToString();

            for (int i = 0; i < a.GetLength(0); i++)
            {
                // Set the new x and y values to the button clicked plus the offset
                int newx = x + a[i, 0];
                int newy = y + a[i, 1];

                if (!((newx < 0) || (newy < 0) || (newx > gameBorder) || (newy > gameBorder)))
                {
                    // Get the colour of the button at the new x and y values
                    Color btnColor = (Color)newBtn[newx, newy].BackColor;
                    string c = btnColor.Name;

                    // Check if the colour of the button is equal to the player 1's colour
                    if (c == p1_colour)
                    {
                        // Check to see if it is player 2 turn
                        if (player_turn == -1)
                        {
                            // If it is player 2's turn, and the button at new x, new y is player 1's colour
                            // swap the colours, take one point off player 1 and add one to player 2
                            subPoints(1, player_turn);
                            newBtn[newx, newy].BackColor = paintColour;
                            addPoints(1);
                        }
                    }
                    // Check if the colour of the button is equal to the player 2's colour
                    else if (c == p2_colour)
                    {
                        // Check to see if it is player 1 turn
                        if (player_turn == 1)
                        {
                            // If it is player 1's turn, and the button at new x, new y is player 2's colour
                            // swap the colours, take one point off player 2 and add one to player 1
                            subPoints(1, player_turn);
                            newBtn[newx, newy].BackColor = paintColour;
                            addPoints(1);
                        }
                    }
                    // If the button is the default colour
                    else if (c == "Honeydew")
                    {
                        // Add one point to the current players scorea and set the button to their colour
                        newBtn[newx, newy].BackColor = paintColour;
                        addPoints(1);
                    }
                    else
                    {
                        // Send an error is the button cannot be painted
                        Console.WriteLine("Error -- > " + btnColor.Name + " Square Cant Be Painted");
                    }
                }
            }
        }


        /*
         * Following Code Was Writen By:
         * 
         * Steven Marshall
         * 170008935
         * 
         */

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an object of the about form and show it
            AboutForm frm = new AboutForm();
            frm.Show();
        }

        private void howToPlayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an object of the how to play form and show it
            HowToPlay frm = new HowToPlay();
            frm.Show();
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an object of the history form and show it
            HistoryForm frm = new HistoryForm();
            frm.Show();
        }
    }
}