﻿/*
 * Cameron McNeill
 * 170014393
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PaintWAR
{
    public class player
    {

        private int points;
        private string name;
        private Color colour;
        private int bombs;
        private int dripping;
        private int infected;

        // Constructor with default values
        public player()
        {
            points = 0;
            bombs = 2;
            dripping = 2;
            infected = 1;
            colour = Color.Black;
            name = "Nothing";
        }

        // Constructor with default weapon values and user defined name/colour
        public player(Color incolour, string inname)
        {
            // Default values
            points = 0;
            bombs = 2;
            dripping = 2;
            infected = 2;

            // User defined
            name = inname;
            colour = incolour;
        }

        // Getter and setter methods for points
        public void setPoints(int p) { points = p; }
        public int getPoints() { return points; }

        // Add and subtract one from the players points
        public void addPoints(int p) { points += p; }
        public void subPoints(int p) { points -= p; }

        // Getter and setter methods for name
        public string getName() { return name; }
        public void setName(string inname) { name = inname; }

        //==============================================================
        // Weapon functions
        //==============================================================
        // Get the count for each of the weapons
        public int getBombs() { return bombs; }
        public int getDripping() { return dripping; }
        public int getInfected() { return infected; }
        
        // Different from the others as this can be used more generally
        public int checkWeapon(string weapon)
        {
            // Return the number of the weapon passed in
            switch (weapon)
            {
                case "bomb":
                    return bombs;

                case "dripping":
                    return dripping;

                case "infected":
                    return infected;
            }

            // Default to return -1 for an error case 
            return -1;
        }

        public void useWeapon(string weapon)
        {
            // Reduce the number of the weapon passed in by 1
            switch (weapon)
            {
                case "bomb":
                    bombs--;
                    break;

                case "dripping":
                    dripping--;
                    break;

                case "infected":
                    infected--;
                    break;

                default:
                    Console.WriteLine("Error --> Invalid Weapon While Removing 1");
                    break;
            }
        }

        //==============================================================
        // Color functions
        //==============================================================
        // Getter and setter methods for the colour
        public Color getColor() { return colour; }
        public void setColour(Color incolour) { colour = incolour; }

    }
}
