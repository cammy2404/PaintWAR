﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace PaintWAR
{
    public partial class Form4 : Form
    {

        public Form4()
        {
            InitializeComponent();
            int lineCount = -1;
            using (var reader = File.OpenText(@"Cuntmonkey.csv"))
            {
                while (reader.ReadLine() != null)
                {
                    lineCount++;
                }
            }
            Console.WriteLine("Number of lines " + lineCount + 1);
            try
            {
                var lines = File.ReadLines("Cuntmonkey.csv");

                for (int i = lineCount; i > -1; i--)
                {
                    string line = lines.ElementAtOrDefault(i); // null if there are less lines
                    tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 25F));


                    string[] words = line.Split(',');
                    foreach (string word in words)
                    {
                        Console.WriteLine("WORD: " + word);
                        //write the lie to console window
                        Label lbl = new Label();
                        lbl.Dock = DockStyle.Fill;
                        lbl.TextAlign = ContentAlignment.MiddleCenter;
                        lbl.Font = new Font("Franklin Gothic Medium", 10);
                        lbl.Text = word;
                        tableLayoutPanel2.Controls.Add(lbl);

                    }
                }
                if (tableLayoutPanel2.RowCount > 10)
                {
                    tableLayoutPanel2.AutoScroll = true;
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }


        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            tableLayoutPanel2.Controls.Clear();
            //tableLayoutPanel2.RowStyles.Clear();



            if (comboBox5.SelectedItem == "Sort Ascending")
            {
                int lineCount = -1;
                using (var reader = File.OpenText(@"Cuntmonkey.csv"))
                {
                    while (reader.ReadLine() != null)
                    {
                        lineCount++;
                    }
                }
                try
                {
                    var lines = File.ReadLines("Cuntmonkey.csv");

                    for (int i = lineCount; i > -1; i--)
                    {
                        string line = lines.ElementAtOrDefault(i); // null if there are less lines
                        tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 25F));

                        // StringBuilder strb = new StringBuilder();
                        string[] words = line.Split(',');
                        foreach (string word in words)
                        {

                            if (line.Contains("30x30"))
                            {
                                Console.WriteLine("WORD: " + word);
                                //write the lie to console window
                                Label lbl = new Label();
                                lbl.Dock = DockStyle.Fill;
                                lbl.TextAlign = ContentAlignment.MiddleCenter;
                                lbl.Font = new Font("Franklin Gothic Medium", 10);
                                lbl.Text = word;
                                tableLayoutPanel2.Controls.Add(lbl);

                                //strb.Append(word + seperator);
                                //File.AppendAllText("Cuntmonkey666.csv", strb.ToString());

                            }

                            if (tableLayoutPanel2.RowCount > 10)
                            {
                                tableLayoutPanel2.AutoScroll = true;
                            }

                        }
                    }
                    //strb.Append("\n");


                    for (int i = lineCount; i > -1; i--)
                    {
                        string line = lines.ElementAtOrDefault(i); // null if there are less lines
                        tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 25F));


                        string[] words = line.Split(',');
                        foreach (string word in words)
                        {
                            if (line.Contains("40x40"))
                            {
                                Console.WriteLine("WORD: " + word);
                                //write the lie to console window
                                Label lbl = new Label();
                                lbl.Dock = DockStyle.Fill;
                                lbl.TextAlign = ContentAlignment.MiddleCenter;
                                lbl.Font = new Font("Franklin Gothic Medium", 10);
                                lbl.Text = word;
                                tableLayoutPanel2.Controls.Add(lbl);
                            }
                            if (tableLayoutPanel2.RowCount > 10)
                            {
                                tableLayoutPanel2.AutoScroll = true;
                            }


                        }
                    }
                    for (int i = lineCount; i > -1; i--)
                    {
                        string line = lines.ElementAtOrDefault(i); // null if there are less lines
                        tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 25F));


                        string[] words = line.Split(',');
                        foreach (string word in words)
                        {
                            if (line.Contains("50x50"))
                            {
                                Console.WriteLine("WORD: " + word);
                                //write the lie to console window
                                Label lbl = new Label();
                                lbl.Dock = DockStyle.Fill;
                                lbl.TextAlign = ContentAlignment.MiddleCenter;
                                lbl.Font = new Font("Franklin Gothic Medium", 10);
                                lbl.Text = word;
                                tableLayoutPanel2.Controls.Add(lbl);
                            }
                            if (tableLayoutPanel2.RowCount > 10)
                            {
                                tableLayoutPanel2.AutoScroll = true;
                            }


                        }
                    }


                }
                catch (Exception ee)
                {
                    Console.WriteLine("Exception: " + ee.Message);
                }
                finally
                {
                    Console.WriteLine("Executing finally block.");
                }
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            string[] csvRows = System.IO.File.ReadAllLines("Cuntmonkey.csv");
            dt.Columns.Add(csvRows[0]);



            for (int x = 0; x < csvRows.Length; x++)
            {
                //for (int y = 0; y < csvRows.Length; y++)
                //{
                    dt.Rows.Add(csvRows[x]);
                //}
            }


            Console.WriteLine(dt.Rows[0][0].ToString()); //first [0] refers to the column and the second [0] to the cell


        }
    }
}
    



